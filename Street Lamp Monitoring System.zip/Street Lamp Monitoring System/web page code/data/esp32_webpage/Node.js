const express = require('express');
const app = express();
const path = require('path');
const fetch = require('node-fetch');  // npm install node-fetch

// Serve static files like HTML, CSS, JS from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Initialize a variable to hold the latest light data
let lightData = {};

// Function to fetch data from ESP32 every 5 seconds
function fetchDataFromESP32() {
  fetch('http://192.168.1.184/esp32_webpage')  // Replace with ESP32 IP address
    .then(response => response.json())
    .then(data => {
      lightData = data;
    })
    .catch(error => {
      console.error('Error fetching data from ESP32:', error);
    });
}

// Set an interval to fetch data every 5 seconds
setInterval(fetchDataFromESP32, 5000);

// Create the /esp32_webpage route
app.get('/esp32_webpage', (req, res) => {
  // Return the latest light data
  res.json(lightData);  // Sending the most recent data to the frontend
});

// Optional: Serve the index.html for your main webpage
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));  // Adjust the path as needed
});

// Start the server
app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
